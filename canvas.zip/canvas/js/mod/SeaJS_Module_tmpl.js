define(function(require, exports, module) {

    //exports.doSth =function(){};
    //module.exports = Point;

});