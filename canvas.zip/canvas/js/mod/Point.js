define(function(require, exports, module) {
    /**
     * 2D点
     * @param x
     * @param y
     * @constructor
     */
    function Point(x,y){
        this.x = x;
        this.y = y;
    }

    module.exports = Point;
});