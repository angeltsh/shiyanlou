# CanvasGrain

简单的 HTML5 Cavnas 粒子制造器

(demo)[http://ol.weixin.qq.com/public/users/jationhuang/canvasworld/main.html]